create database asker

use asker

CREATE TABLE isimler (
  id int identity(1,1),
  ad varchar(25),
  primary key (id)
  )
  

INSERT INTO isimler VALUES ('Aba');
INSERT INTO isimler VALUES ('Abaca');
INSERT INTO isimler VALUES ('Abacan');
INSERT INTO isimler VALUES ('Aba�');
INSERT INTO isimler VALUES ('Rabi');
INSERT INTO isimler VALUES ('Rabia');
INSERT INTO isimler VALUES ('Rabih');
INSERT INTO isimler VALUES ('Saba');
INSERT INTO isimler VALUES ('Sabah');
INSERT INTO isimler VALUES ('Sabahat');
INSERT INTO isimler VALUES ('Sabahattin');
INSERT INTO isimler VALUES ('Yabgu');
INSERT INTO isimler VALUES ('Yab�z');
INSERT INTO isimler VALUES ('Yalabuk');
INSERT INTO isimler VALUES ('Yalazabay');
INSERT INTO isimler VALUES ('B�r�han');
INSERT INTO isimler VALUES ('B�r�kan');
INSERT INTO isimler VALUES ('Bucak');
INSERT INTO isimler VALUES ('Budak');
INSERT INTO isimler VALUES ('Budunal');
INSERT INTO isimler VALUES ('Budunalp');
INSERT INTO isimler VALUES ('Bu�day');
INSERT INTO isimler VALUES ('Bu�ra');
INSERT INTO isimler VALUES ('G�nseli');
INSERT INTO isimler VALUES ('G�nsenin');
INSERT INTO isimler VALUES ('G�nser');
INSERT INTO isimler VALUES ('G�nseren');
INSERT INTO isimler VALUES ('G�n�en');
INSERT INTO isimler VALUES ('G�ntekin');
INSERT INTO isimler VALUES ('G�nten');
INSERT INTO isimler VALUES ('G�nt�re');
INSERT INTO isimler VALUES ('G�nver');
INSERT INTO isimler VALUES ('G�nyeli');
INSERT INTO isimler VALUES ('G�rel');
INSERT INTO isimler VALUES ('G�rer');
INSERT INTO isimler VALUES ('G�rsel');
INSERT INTO isimler VALUES ('Kerem');
INSERT INTO isimler VALUES ('Kerim');
INSERT INTO isimler VALUES ('Kerime');
INSERT INTO isimler VALUES ('Kermen');
INSERT INTO isimler VALUES ('Kesek');
INSERT INTO isimler VALUES ('Kesim');
INSERT INTO isimler VALUES ('Keskin');
INSERT INTO isimler VALUES ('Keskinel');
INSERT INTO isimler VALUES ('Keskiner');
INSERT INTO isimler VALUES ('Ke�fi');
INSERT INTO isimler VALUES ('Ke�fiye');
INSERT INTO isimler VALUES ('Kete');
INSERT INTO isimler VALUES ('Keven');
INSERT INTO isimler VALUES ('Kevkep');
INSERT INTO isimler VALUES ('Kevn�');
INSERT INTO isimler VALUES ('Kevser');
INSERT INTO isimler VALUES ('Key');
INSERT INTO isimler VALUES ('Keyfi');
INSERT INTO isimler VALUES ('Kezer');
INSERT INTO isimler VALUES ('K�nel');
INSERT INTO isimler VALUES ('K�ner');
INSERT INTO isimler VALUES ('K�rteke');
INSERT INTO isimler VALUES ('Neyire');
INSERT INTO isimler VALUES ('Neyyire');
INSERT INTO isimler VALUES ('Neyyiri');
INSERT INTO isimler VALUES ('Neyzen');
INSERT INTO isimler VALUES ('Nezih');
INSERT INTO isimler VALUES ('Nezihe');
INSERT INTO isimler VALUES ('Nezihi');
INSERT INTO isimler VALUES ('Nezir');
INSERT INTO isimler VALUES ('Nezire');
INSERT INTO isimler VALUES ('Nil�fer');
INSERT INTO isimler VALUES ('Nimet');
INSERT INTO isimler VALUES ('Onerim');
INSERT INTO isimler VALUES ('Onguner');
INSERT INTO isimler VALUES ('Ong�ner');
INSERT INTO isimler VALUES ('Ong�ne�');
INSERT INTO isimler VALUES ('Onuker');
INSERT INTO isimler VALUES ('Onuktekin');
INSERT INTO isimler VALUES ('Onursev');
INSERT INTO isimler VALUES ('�keer');
INSERT INTO isimler VALUES ('�kelik');
INSERT INTO isimler VALUES ('�ker');
INSERT INTO isimler VALUES ('�kke�');
INSERT INTO isimler VALUES ('�kmen');
INSERT INTO isimler VALUES ('�kmener');
INSERT INTO isimler VALUES ('�kte');
INSERT INTO isimler VALUES ('�ktem');
INSERT INTO isimler VALUES ('�ktemer');
INSERT INTO isimler VALUES ('�kten');
INSERT INTO isimler VALUES ('�ktener');
INSERT INTO isimler VALUES ('�len');
select * from isimler