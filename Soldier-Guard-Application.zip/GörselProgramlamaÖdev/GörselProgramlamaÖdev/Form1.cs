﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Collections;

namespace GörselProgramlamaÖdev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Form2 frm2 = new Form2();

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-QTANR4U;Initial Catalog=asker;Integrated Security=True");

        void listtemizle()
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox7.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frm2.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listtemizle();
            ArrayList diziler = new ArrayList();
            Random rastgele = new Random();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from isimler", baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                diziler.Add(oku["ad".ToString()]);
            }
            for (int i = 1; i <= 10; i++)
            {
                int pzrtsi = rastgele.Next(diziler.Count);
                int salı = rastgele.Next(diziler.Count);
                int crsmb = rastgele.Next(diziler.Count);
                int prsmb = rastgele.Next(diziler.Count);
                int cuma = rastgele.Next(diziler.Count);
                int cmrtsi = rastgele.Next(diziler.Count);
                int pzr = rastgele.Next(diziler.Count);
                listBox1.Items.Add(diziler[pzrtsi]);
                listBox2.Items.Add(diziler[salı]);
                listBox3.Items.Add(diziler[crsmb]);
                listBox4.Items.Add(diziler[prsmb]);
                listBox5.Items.Add(diziler[cuma]);
                listBox6.Items.Add(diziler[cmrtsi]);
                listBox7.Items.Add(diziler[pzr]);
            }
            baglanti.Close();
        }

        private void listBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
        }
