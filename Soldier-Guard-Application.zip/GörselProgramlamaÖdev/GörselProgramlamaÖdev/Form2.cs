﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;


namespace GörselProgramlamaÖdev
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-QTANR4U;Initial Catalog=asker;Integrated Security=True");
        private object txtad;

        void datagreaddoldur()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from isimler", baglanti);
            SqlDataAdapter da = new SqlDataAdapter(komut);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();


        }
        
        

        private void button3_Click(object sender, EventArgs e)
        {
            datagreaddoldur();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (baglanti.State==ConnectionState.Closed)
                    baglanti.Open();

                    SqlCommand komut = new SqlCommand("insert into isimler(ad) values (@ad)",baglanti);
                    komut.Parameters.AddWithValue("@ad", textBox1.Text);
                    komut.ExecuteNonQuery();
                    baglanti.Close();
                    MessageBox.Show("Kayıt Oldu");
                
            }
            catch (Exception hata)
            {

                MessageBox.Show(hata.Message);
            }
        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            string silmeSorgusu = "Delete from isimler where ad=@ad"; // silme kodu
            SqlCommand silme = new SqlCommand(silmeSorgusu, baglanti);
            silme.Parameters.AddWithValue("@ad", textBox5.Text);
            silme.ExecuteNonQuery();
            MessageBox.Show("Kayıt Silindi");
            baglanti.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            string güncellemekomout = "Update isimler Set ad = '" + textBox5.Text + "'where id='" + textBox2.Text + "'"; //Güncelleme kodu
            SqlCommand güncelle = new SqlCommand(güncellemekomout, baglanti);
            güncelle.Parameters.AddWithValue("@ad", textBox5.Text);
            güncelle.ExecuteNonQuery();
            MessageBox.Show("Güncellendi");
            baglanti.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
